# Databases-SQL--Mini_Projects
This project is designed to simulate the creation of an SQL DB Schema, with the purpose of using it in demonstration for basic data processing using Queries and other useful mechanics (Views, Procedures, Triggers, etcetera), through various exercises.
